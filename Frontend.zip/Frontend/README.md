# What If Insights Engine Frontend

This is the React-based frontend for the What If Insights Engine. It includes components for data upload, display, and navigation.

## Setup

1. Navigate to the `frontend` directory.
2. Install dependencies:
    ```bash
    npm install
    ```
3. Run the development server:
    ```bash
    npm start
    ```
4. Access the frontend at `http://localhost:3000`.

## Features
- Upload beneficiary data.
- View data insights with sentiment analysis.
