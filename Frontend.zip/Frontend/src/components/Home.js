import React from 'react';

function Home() {
    return (
        <div>
            <h1>Welcome to The What If Insights Engine</h1>
            <p>Navigate to upload or view data insights.</p>
        </div>
    );
}

export default Home;
        