import React, { useState } from 'react';
import { uploadData } from '../api';

function DataUpload() {
    const [data, setData] = useState('');
    const [tags, setTags] = useState('');
    const [response, setResponse] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const result = await uploadData({ data, tags: tags.split(',') });
        setResponse(result);
    };

    return (
        <div>
            <h1>Upload Data</h1>
            <form onSubmit={handleSubmit}>
                <label>Data:</label><br />
                <textarea value={data} onChange={(e) => setData(e.target.value)} required /><br />
                <label>Tags (comma-separated):</label><br />
                <input value={tags} onChange={(e) => setTags(e.target.value)} required /><br />
                <button type="submit">Upload</button>
            </form>
            {response && (
                <div>
                    <h2>Response:</h2>
                    <p>ID: {response.id}</p>
                    <p>Data: {response.data}</p>
                    <p>Tags: {response.tags.join(', ')}</p>
                    <p>Sentiment: {response.sentiment}</p>
                </div>
            )}
        </div>
    );
}

export default DataUpload;
        