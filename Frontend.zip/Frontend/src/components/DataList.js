import React, { useEffect, useState } from 'react';
import { fetchData } from '../api';

function DataList() {
    const [data, setData] = useState([]);

    useEffect(() => {
        async function getData() {
            const result = await fetchData();
            setData(result);
        }
        getData();
    }, []);

    return (
        <div>
            <h1>Data List</h1>
            <ul>
                {data.map((item) => (
                    <li key={item.id}>
                        <strong>Data:</strong> {item.data} <br />
                        <strong>Tags:</strong> {item.tags.join(', ')} <br />
                        <strong>Sentiment:</strong> {item.sentiment}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default DataList;
        