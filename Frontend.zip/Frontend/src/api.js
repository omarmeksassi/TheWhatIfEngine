const BASE_URL = 'http://localhost:8000';

export async function fetchData() {
    const response = await fetch(`${BASE_URL}/data/`);
    return await response.json();
}

export async function uploadData(data) {
    const response = await fetch(`${BASE_URL}/upload/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });
    return await response.json();
}
        