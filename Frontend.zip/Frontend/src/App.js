import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import DataList from './components/DataList';
import DataUpload from './components/DataUpload';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/data" element={<DataList />} />
                <Route path="/upload" element={<DataUpload />} />
            </Routes>
        </Router>
    );
}

export default App;
        